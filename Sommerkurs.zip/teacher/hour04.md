# Stunde 4 - Character Editor: Grafische Verwaltung (Lehrerversion)

In dieser Stunde baut der Schüler eine **grafische Benutzeroberfläche (GUI)** für die Character Library – einen Character Editor mit einer Liste aller Charaktere und Buttons zum Erstellen, Bearbeiten und Löschen. Anders wie in Stunde 2 (Debugging) schreibt der Schüler hier **selbstständig Code** nach Anleitung.

Im Gegensatz zu Stunde 2 enthält der Code, den der Schüler schreibt, **keine absichtlichen Fehler**. Der Schüler baut direkt sauberen, funktionierenden Code – analog zum Aufbau aus Stunde 1 und 3.

---

## ui/__init__.py

```python
# ui - Paket für Benutzeroberfächen-Komponenten
# Enthält Fenster, Dialoge und Widgets für die grafische Oberfläche
```

Diese Datei macht den `ui/`-Ordner zu einem Python-Paket, analog zu `core/__init__.py`. Sie ist nur ein Kommentar – dient nur dazu, dass man `from ui.character_editor import CharacterEditor` schreiben kann.

---

## ui/character_editor.py

```python
# Character Editor für Record Studio
# Grafische Oberfläche zur Verwaltung von Charakteren (CRUD-Operationen)
# Zeigt eine Liste aller Charaktere an und ermöglicht das
# Erstellen, Bearbeiten und Löschen von Charakteren in der CharacterLibrary.

# Importiert die Tkinter-Bibliothek für GUI-Fenster
import tkinter as tk
# Importiert das ttk-Modul für erweiterte Widgets (Treeview) und messagebox für Dialoge
from tkinter import ttk, messagebox

# Importiert die CharacterLibrary für CRUD-Operationen auf Charakteren
from core.character_library import CharacterLibrary


class CharacterEditor(tk.Toplevel):
    """Grafischer Editor für die Character Library.

    Erbt von tk.Toplevel, um ein eigenständiges Fenster zu erzeugen,
    das als Kind des Hauptfensters (RecordStudioApp) erscheint.

    Die Klasse zeigt alle Charaktere in einer ttk.Treeview-Liste an
    und bietet drei Aktionen: Neu erstellen, Bearbeiten und Löschen.
    Jede Aktion öffnet bei Bedarf einen Toplevel-Dialog mit Eingabefeldern.

    Attribute:
        character_library: Die CharacterLibrary-Instanz, die die Daten verwaltet
        selected_character_id: ID des aktuell in der Liste ausgewählten Charakters
        tree: Die ttk.Treeview-Widget mit den Spalten Name und Beschreibung
    """

    def __init__(self, parent, character_library: CharacterLibrary):
        """Initialisiert den Character Editor.

        Args:
            parent: Elternfenster (RecordStudioApp-Instanz)
            character_library: CharacterLibrary-Instanz für CRUD-Operationen
        """
        # Ruft den Konstruktor der Elternklasse (tk.Toplevel) auf
        super().__init__(parent)

        # Referenz auf die CharacterLibrary speichern, um später CRUD-Operationen auszuführen
        self.character_library = character_library

        # ID des aktuell ausgewählten Charakters (None, wenn nichts ausgewählt)
        self.selected_character_id = None

        # Fenster-Titel festlegen (erscheint in der Titelleiste)
        self.title("Charaktere verwalten")
        # Fenstergröße festlegen: 600 Pixel breit, 400 Pixel hoch
        self.geometry("600x400")
        # Das Fenster als Tochter des Hauptfensters kennzeichnen (transient)
        # Dadurch folgt es dem Hauptfenster bei Minimieren und erscheint zentriert darüber
        self.transient(parent)

        # Die Benutzeroberfläche erstellen (Treeview, Buttons, Schließen-Button)
        self._build_ui()

        # Die Liste der Charaktere beim Start initial befüllen
        self._refresh_list()

    def _build_ui(self):
        """Erstellt alle sichtbaren Elemente des Editor-Fensters.

        Aufbau:
        - Oben: ttk.Treeview mit zwei Spalten (Name, Beschreibung)
        - Darunter: Drei Buttons (Neuer Charakter, Bearbeiten, Löschen)
        - Unten: Schließen-Button
        """
        # ---------- TREVIEW (Charakterliste) ----------
        # ttk.Treeview mit zwei benannten Spalten erstellen
        # show="headings" versteckt die Standard-Baum-Spalte ganz links
        self.tree = ttk.Treeview(
            self,
            columns=("name", "description"),
            show="headings"
        )

        # Spaltenüberschriften (Headings) festlegen
        self.tree.heading("name", text="Name")
        self.tree.heading("description", text="Beschreibung")

        # Spaltenbreiten festlegen (Gesamtbreite passt sich an Fenstergröße an)
        self.tree.column("name", width=200)
        self.tree.column("description", width=350)

        # Treeview mit Rand und automatischem Resize platzieren
        self.tree.pack(fill="both", expand=True, padx=10, pady=10)

        # Wenn der Benutzer eine Zeile in der Treeview auswählt,
        # wird _on_tree_select aufgerufen (aktiviert/deaktiviert Edit- und Delete-Buttons)
        self.tree.bind("<<TreeviewSelect>>", self._on_tree_select)

        # ---------- BUTTON-LEISTE ----------
        # Einen Rahmen (Frame) für die drei Aktions-Buttons erstellen
        button_frame = tk.Frame(self)
        button_frame.pack(pady=10)

        # Button: Neuer Charakter – öffnet einen Dialog zur Eingabe von Name, Bildpfad, Beschreibung
        self.new_btn = tk.Button(
            button_frame,
            text="Neuer Charakter",
            command=self._open_create_dialog,
            font=tk.font.Font(family="Arial", size=10)
        )
        self.new_btn.pack(side="left", padx=5)

        # Button: Bearbeiten – nur aktiv, wenn eine Zeile ausgewählt ist
        # Wird in _on_tree_select aktiviert/deaktiviert
        self.edit_btn = tk.Button(
            button_frame,
            text="Bearbeiten",
            command=self._open_edit_dialog,
            state="disabled",
            font=tk.font.Font(family="Arial", size=10)
        )
        self.edit_btn.pack(side="left", padx=5)

        # Button: Löschen – nur aktiv, wenn eine Zeile ausgewählt ist
        # Zeigt vor dem Löschen einen Bestätigungsdialog an
        self.delete_btn = tk.Button(
            button_frame,
            text="Löschen",
            command=self._delete_character,
            state="disabled",
            font=tk.font.Font(family="Arial", size=10)
        )
        self.delete_btn.pack(side="left", padx=5)

        # ---------- SCHLIESSEN-BUTTON ----------
        # Schließt das Editor-Fenster
        self.close_btn = tk.Button(
            self,
            text="Schließen",
            command=self.destroy,
            font=tk.font.Font(family="Arial", size=10)
        )
        self.close_btn.pack(pady=10)

    def _refresh_list(self):
        """Lädt alle Charaktere neu und füllt die Treeview-Liste auf.

        Die Methode wird nach jeder Änderung (Neu/Bearbeiten/Löschen)
        aufgerufen, um sicherzustellen, dass die Anzeige aktuell ist.
        """
        # Alle vorhandenen Einträge in der Treeview entfernen
        for item in self.tree.get_children():
            self.tree.delete(item)

        # Alle Charaktere laden (get_all_characters() liefert sie bereits alphabetisch sortiert)
        characters = self.character_library.get_all_characters()

        # Jeden Charakter als neue Zeile in die Treeview einfügen
        # Die character_id wird als iid (item id) verwendet, damit wir später
        # den zugehörigen Charakter für Bearbeiten/Löschen wiederfinden
        for character in characters:
            self.tree.insert(
                "",
                "end",
                iid=character.character_id,
                values=(character.name, character.description)
            )

    def _on_tree_select(self, event):
        """Wird aufgerufen, wenn der Benutzer eine Zeile in der Treeview auswählt.

        Aktiviert die "Bearbeiten"- und "Löschen"-Buttons, wenn eine Zeile
        ausgewählt ist, und deaktiviert sie, wenn die Auswahl aufgehoben wird.

        Args:
            event: Das TreeviewSelect-Ereignis (wird von Tkinter automatisch übergeben)
        """
        # Die aktuell ausgewählten Item-IDs abrufen
        selected = self.tree.selection()

        if selected:
            # Eine Zeile ist ausgewählt: die character_id speichern und Buttons aktivieren
            self.selected_character_id = selected[0]
            self.edit_btn.config(state="normal")
            self.delete_btn.config(state="normal")
        else:
            # Keine Zeile mehr ausgewählt: ID zurücksetzen und Buttons deaktivieren
            self.selected_character_id = None
            self.edit_btn.config(state="disabled")
            self.delete_btn.config(state="disabled")

    def _open_create_dialog(self):
        """Öffnet einen Dialog zum Erstellen eines neuen Charakters.

        Ruft die interne Methode _open_character_dialog auf, ohne eine
        character_id zu übergeben (was den Modus "Neu" auslöst).
        """
        # character_id=None signalisiert: Neuer Charakter (nicht Bearbeiten)
        self._open_character_dialog(character_id=None)

    def _open_edit_dialog(self):
        """Öffnet einen Dialog zum Bearbeiten des ausgewählten Charakters.

        Die Eingabefelder werden mit den aktuellen Werten des Charakters
        vorbelegt. Beim Speichern wird update_character() aufgerufen.
        """
        # Wenn nichts ausgewählt ist, nichts tun (Sicherheitscheck)
        if self.selected_character_id is None:
            return

        # character_id setzen: Der Dialog weiß, dass er bearbeiten (nicht erstellen) soll
        self._open_character_dialog(character_id=self.selected_character_id)

    def _open_character_dialog(self, character_id=None):
        """Öffnet einen gemeinsamen Dialog für Neu- und Bearbeiten-Modus.

        Der Dialog enthält Eingabefelder für Name, Bildpfad und Beschreibung.
        Im Bearbeiten-Modus (character_id ist gesetzt) werden die Felder
        mit den aktuellen Werten vorbelegt.

        Args:
            character_id: None für einen neuen Charakter, sonst die ID
                          des zu bearbeitenden Charakters
        """
        # Bestimme, ob es um Erstellen oder Bearbeiten geht
        # (wird für den Fenster-Titel verwendet)
        is_edit_mode = character_id is not None

        # ---------- DIALOG-FENSTER ERSTELLEN ----------
        dialog = tk.Toplevel(self)
        dialog.title("Charakter bearbeiten" if is_edit_mode else "Neuer Charakter")
        dialog.geometry("400x300")
        # Der Dialog ist ein Tochterfenster des Editors (transient)
        dialog.transient(self)

        # ---------- EINGABEFELDER ----------
        # Name-Eingabe
        tk.Label(dialog, text="Name:").pack(pady=(20, 5))
        name_var = tk.StringVar()
        tk.Entry(dialog, textvariable=name_var, width=40).pack()

        # Bildpfad-Eingabe
        tk.Label(dialog, text="Bildpfad:").pack(pady=(10, 5))
        image_var = tk.StringVar()
        tk.Entry(dialog, textvariable=image_var, width=40).pack()

        # Beschreibung-Eingabe
        tk.Label(dialog, text="Beschreibung:").pack(pady=(10, 5))
        desc_var = tk.StringVar()
        tk.Entry(dialog, textvariable=desc_var, width=40).pack()

        # Wenn Bearbeiten-Modus: Die Eingabefelder mit den aktuellen Werten vorbelegen
        if is_edit_mode:
            character = self.character_library.get_character(character_id)
            if character:
                name_var.set(character.name)
                image_var.set(character.image_path)
                desc_var.set(character.description)

        # ---------- SPEICHERN-BUTTON ----------
        # Die save()-Funktion wird als lokale Funktion definiert,
        # weil sie Zugriff auf die Eingabevariablen und character_id braucht
        def save():
            """Liest die Eingaben aus, speichert den Charakter und schließt den Dialog."""
            # Eingaben auslesen und trimmen (entfernt führende/trailing Leerzeichen)
            name = name_var.get().strip()
            image_path = image_var.get().strip()
            description = desc_var.get().strip()

            # Einfache Validierung: Name darf nicht leer sein
            if not name:
                messagebox.showwarning("Warnung", "Bitte gib einen Namen ein!")
                return

            if is_edit_mode:
                # Bearbeiten: update_character mit der character_id aufrufen
                self.character_library.update_character(
                    character_id,
                    name=name,
                    image_path=image_path,
                    description=description
                )
            else:
                # Neu erstellen: create_character aufrufen (ID wird automatisch generiert)
                self.character_library.create_character(
                    name=name,
                    image_path=image_path,
                    description=description
                )

            # Die Treeview-Liste nach der Änderung neu befüllen
            self._refresh_list()

            # Dialog schließen
            dialog.destroy()

        # Speichern-Button mit der save()-Funktion verknüpfen
        tk.Button(dialog, text="Speichern", command=save).pack(pady=20)

    def _delete_character(self):
        """Löscht den ausgewählten Charakter nach einer Bestätigung.

        Zeigt zuerst einen Bestätigungsdialog (messagebox.askyesno) an.
        Erst wenn der Benutzer mit "Ja" bestätigt, wird der Charakter
        aus der CharacterLibrary gelöscht und die Liste aktualisiert.
        """
        # Sicherheitscheck: Wenn nichts ausgewählt ist, nichts tun
        if self.selected_character_id is None:
            return

        # Bestätigungsdialog anzeigen: "Charakter wirklich löschen?"
        # askyesno gibt True zurück, wenn der Benutzer auf "Ja" klickt
        if not messagebox.askyesno(
            "Bestätigung",
            "Charakter wirklich löschen?"
        ):
            # Benutzer hat "Nein" geklickt: Nichts tun
            return

        # Charakter in der Bibliothek löschen
        self.character_library.delete_character(self.selected_character_id)

        # Liste neu laden, damit der gelöschte Charakter verschwindet
        self._refresh_list()

        # Auswahl zurücksetzen und Buttons deaktivieren
        self.selected_character_id = None
        self.edit_btn.config(state="disabled")
        self.delete_btn.config(state="disabled")
```

### Erklärung der wichtigsten Code-Abschnitte

#### Klasse erbt von `tk.Toplevel`

```python
class CharacterEditor(tk.Toplevel):
```
- `tk.Toplevel` erzeugt ein eigenständiges Fenster, das als Kind eines anderen Fensters (hier: `RecordStudioApp`) erscheint.
- Im Gegensatz zu `tk.Tk` (das nur **einmal** pro Anwendung existieren darf) kann es mehrere `Toplevel`-Fenster geben.

#### Konstruktor – Elternfenster und Bibliothek übergeben

```python
def __init__(self, parent, character_library: CharacterLibrary):
    super().__init__(parent)
    self.character_library = character_library
    self.selected_character_id = None
    self.transient(parent)
```
- `parent` ist das Hauptfenster – wichtig für `transient()`, damit das Fenster zusammen mit dem Hauptfenster minimiert wird.
- `character_library` wird gespeichert, damit alle Methoden (Erstellen, Bearbeiten, Löschen) darauf zugreifen können.
- `selected_character_id` speichert die ID des gerade ausgewählten Charakters in der Liste (oder `None`).

#### Treeview – zwei Spalten ohne Bildvorschau

```python
self.tree = ttk.Treeview(self, columns=("name", "description"), show="headings")
```
- `columns=("name", "description")` definiert zwei benannte Spalten.
- `show="headings"` versteckt die Standard-Baum-Spalte (die links von den Daten steht) – wichtig, damit nur die zwei Spalten angezeigt werden.
- Ohne `show="headings"` würde eine leere Spalte links erscheinen.

#### `iid` = `character_id` – die Verbindung zwischen Liste und Daten

```python
self.tree.insert("", "end", iid=character.character_id, values=(character.name, character.description))
```
- `iid` (item id) ist die interne ID des Treeview-Eintrags.
- Wir setzen sie auf `character.character_id`, damit wir später über `self.tree.selection()` die character_id des ausgewählten Eintrags erhalten – nicht nur den angezeigten Namen.
- Das ist entscheidend: Die Treeview zeigt **Namen** an, aber die Logik arbeitet mit der **character_id**.

#### `_on_tree_select` – Buttons dynamisch aktivieren

```python
def _on_tree_select(self, event):
    selected = self.tree.selection()
    if selected:
        self.selected_character_id = selected[0]
        self.edit_btn.config(state="normal")
        self.delete_btn.config(state="disabled")
```
- Die `<<TreeviewSelect>>`-Event-Bindung ruft diese Methode auf, wenn der Benutzer eine Zeile klickt.
- `self.tree.selection()` gibt eine Liste der ausgewählten Item-IDs zurück (hier genau eine, da keine Multi-Select-Einstellung).
- Die Buttons "Bearbeiten" und "Löschen" werden nur aktiv, wenn eine Zeile ausgewählt ist – das verhindert Fehlermeldungen beim Klick auf nichts.

#### Gemeinsamer Dialog für Neu- und Bearbeiten-Modus

```python
def _open_character_dialog(self, character_id=None):
    is_edit_mode = character_id is not None
    dialog = tk.Toplevel(self)
    ...
    if is_edit_mode:
        character = self.character_library.get_character(character_id)
        name_var.set(character.name)
        ...
```
- Ein einziger Dialog wird für beide Modi verwendet – das vermeidet Code-Duplizierung.
- `character_id=None` → Neuer Charakter (leere Felder).
- `character_id` gesetzt → Bearbeiten (Felder werden über `get_character()` vorbelegt).
- Die `save()`-Funktion ist eine lokale Funktion, weil sie Zugriff auf die Eingabevariablen (`name_var`, etc.) und `character_id` braucht.

#### Bestätigungsdialog vor dem Löschen

```python
if not messagebox.askyesno("Bestätigung", "Charakter wirklich löschen?"):
    return
self.character_library.delete_character(self.selected_character_id)
```
- `messagebox.askyesno()` zeigt einen Dialog mit "Ja" und "Nein" an.
- Erst bei "Ja" (`True`) wird `delete_character()` aufgerufen.
- Das verhindert versehentliches Löschen.

#### `_refresh_list()` nach jeder Änderung

```python
def _refresh_list(self):
    for item in self.tree.get_children():
        self.tree.delete(item)
    characters = self.character_library.get_all_characters()
    for character in characters:
        self.tree.insert("", "end", iid=character.character_id, values=(character.name, character.description))
```
- Zuerst werden alle Einträge gelöscht (`get_children()` gibt alle Item-IDs zurück).
- Dann werden alle Charaktere neu geladen und eingefügt.
- Diese Methode wird nach **jeder** Änderung (Neu, Bearbeiten, Löschen) aufgerufen, damit die Anzeige immer aktuell ist.

---

## app.py (Erweiterung)

In `app.py` werden drei Änderungen gemacht: Ein neuer Import, ein neuer Button und eine neue Methode.

```python
# Record Studio - Hauptanwendung
# Diese Datei startet das Tkinter-Fenster der Anwendung.
# Inkludiert Benutzer-Profile Funktionalität

# Importiert die Tkinter-Bibliothek für GUI-Fenster
import tkinter as tk
# Importiert das font-Modul für Schriftarten-Einstellungen
from tkinter import font, ttk

# Importiert den ProfileManager für Benutzerprofile
from profiles.profile_manager import ProfileManager

# Importiert die CharacterLibrary für Charakter-Verwaltung
from core.character_library import CharacterLibrary

# Importiert den CharacterEditor für die grafische Charakter-Verwaltung
from ui.character_editor import CharacterEditor


class RecordStudioApp(tk.Tk):
    """Hauptklasse der Record Studio Anwendung.
    
    Erbt von tk.Tk, um das Hauptfenster zu definieren.
    In zukünftigen Stunden können hier weitere Module (Frames)
    eingehängt werden.
    """
    
    def __init__(self):
        # Ruft den Konstruktor der Elternklasse (tk.Tk) auf
        super().__init__()
        
        # Initialisiert den Profil-Manager
        self.profile_manager = ProfileManager()
        
        # Initialisiert die Charakter-Bibliothek
        self.character_library = CharacterLibrary()
        
        # Setzt den Titel des Fensters (erscheint in der Titelleiste)
        self.title("Record Studio")
        # Definiert die Startgröße des Fensters (Breite x Höhe in Pixeln)
        self.geometry("1280x800")
        
        # Legt fest, dass das Fenster nicht kleiner als 800x600 Pixel werden kann
        self.minsize(800, 600)
        
        # Ruft die Methode auf, die das Fenster zentriert
        self._center_window()
        
        # Ruft die Methode auf, die die Benutzeroberfläche erstellt
        self._build_ui()
        
        # Zeigt die geladenen Profile beim Start an
        self._show_loaded_profiles()
        
        # Zeigt die geladenen Charaktere beim Start an
        self._show_loaded_characters()
    
    # ... (_show_loaded_profiles, _show_loaded_characters, _center_window, _build_ui,
    #      _get_user_display_names, _select_profile, _create_profile_dialog,
    #      _delete_profile, _edit_profile_dialog, _refresh_profile_list) bleiben unverändert

    def _open_character_editor(self):
        """Öffnet den Character Editor zum Verwalten von Charakteren.
        
        Erstellt eine Instanz des CharacterEditor-Fensters und übergibt
        die CharacterLibrary-Instanz, damit der Editor CRUD-Operationen
        (Erstellen, Lesen, Aktualisieren, Löschen) ausführen kann.
        """
        # CharacterEditor als Tochterfenster des Hauptfensters öffnen
        # Die CharacterLibrary wird übergeben, damit der Editor auf die Daten zugreifen kann
        CharacterEditor(self, self.character_library)


def main():
    """Einstiegspunkt der Anwendung."""
    # Erstellt eine Instanz der Hauptanwendung
    app = RecordStudioApp()
    # Startet die Tkinter-Ereignisschleife (wartet auf Benutzereingaben)
    app.mainloop()


# Standard-Guard: Nur ausführen, wenn diese Datei direkt gestartt wird
if __name__ == "__main__":
    # Ruft die main-Funktion auf
    main()
```

### Erklärung der app.py-Änderungen

- **Import**: `from ui.character_editor import CharacterEditor` importiert die neue Klasse. Der `ui/`-Ordner muss ein Python-Paket sein (dafür brauchen wir `ui/__init__.py`).
- **Button**: Der "Charaktere verwalten"-Button wird in `_build_ui()` bei `relx=0.5, rely=0.85` platziert – unterhalb der Profil-Buttons. Er ruft `_open_character_editor()` auf.
- **Methode**: `_open_character_editor()` erstellt einfach eine Instanz: `CharacterEditor(self, self.character_library)`. Das Hauptfenster (`self`) wird als Eltern übergeben, und die bereits initialisierte `CharacterLibrary` wird weitergegeben.

---

## Warum diese Architektur?

### CharacterEditor als `tk.Toplevel` (nicht als `tk.Tk`)
- `tk.Tk` darf nur **einmal** pro Anwendung existieren (es ist das Hauptfenster).
- `tk.Toplevel` ist für alle weiteren Fenster – das macht es zur natürlichen Wahl für einen Editor-Dialog.
- Durch `transient(parent)` wird das Fenster als "modale" Tochterrolle gekennzeichnet.

### Gemeinsamer Dialog für Neu- und Bearbeiten-Modus
- Statt zwei fast identische Dialoge zu schreiben, wird ein einziger Dialog verwendet, der durch den Parameter `character_id` unterscheidet.
- Das spart Code und macht das Programm einfacher zu warten.

### `iid` = `character_id` in der Treeview
- Die Treeview zeigt Namen an, aber die Logik braucht die ID.
- Durch das Setzen von `iid=character.character_id` beim Einfügen ist der Sprung von "ausgewählte Zeile" → "character_id" trivial: `self.tree.selection()[0]` liefert direkt die ID.

---

## Mögliche Stolperfallen beim Schüler

1. **`show="headings"` vergessen**
   - Ohne diesen Parameter erscheint eine leere Spalte links neben den eigentlichen Daten.
   - Der Schüler denkt, die Spalten seien falsch konfiguriert.

2. **`character_id` vs. angezeigter Name verwechseln**
   - Die Treeview zeigt den **Namen** an, aber `update_character()` und `delete_character()` brauchen die **character_id**.
   - Schüler versuchen, `get_character("Max Mustermann")` aufzurufen – das schlägt fehl, weil die ID z.B. `max_mustermann_1705312345` heißt.
   - Lösung: `iid=character.character_id` beim Einfügen setzen, dann `self.tree.selection()[0]` als ID verwenden.

3. **Bestätigungsdialog vor dem Löschen vergessen**
   - Ohne `messagebox.askyesno()` wird der Charakter sofort gelöscht, wenn der Benutzer auf "Löschen" klickt.
   - Das ist besonders gefährlich, wenn die Buttons nicht deaktiviert sind und versehentlich geklickt wird.

4. **Liste nach Änderung nicht aktualisiert**
   - Nach `create_character()`, `update_character()` oder `delete_character()` muss `_refresh_list()` aufgerufen werden.
   - Ohne die Aktualisierung erscheint die neue Änderung nicht in der Treeview, obwohl die Daten in der JSON-Datei gespeichert wurden.

5. **Buttons "Bearbeiten" und "Löschen" nicht aktivieren/deaktivieren**
   - Wenn die Buttons immer aktiv sind (auch ohne Auswahl), stürzt das Programm ab, wenn der Benutzer darauf klickt, ohne eine Zeile ausgewählt zu haben.
   - Die `_on_tree_select`-Methode muss die Buttons mit `state="normal"` / `state="disabled"` umschalten.

6. **`dialog.transient(parent)` vergessen**
   - Ohne `transient()` erscheint der Dialog nicht als Tochterfenster des Editors.
   - Das kann zu zersplitterten Fenstern führen, die nicht zusammen minimiert werden.

7. **Import-Pfad falsch**
   - `from ui.character_editor import CharacterEditor` erfordert, dass `ui/__init__.py` existiert.
   - Ohne die `__init__.py` schlägt der Import mit `ModuleNotFoundError` fehl.

8. **Eingabefelder nicht vorbelegen im Bearbeiten-Modus**
   - Wenn der Schüler im Edit-Dialog die Werte nicht mit `get_character()` vorbelegt, sieht der Benutzer leere Felder – obwohl er "Bearbeiten" geklickt hat.
   - Wichtig: `name_var.set(character.name)` etc. im `is_edit_mode`-Block.

---

## Mögliche Erweiterungen

- **Bildvorschau**: Ein kleines `tk.Canvas` oder `tk.Label` mit `PhotoImage`, das das Charakter-Bild anzeigt
- **Suche**: Eine Eingabemöglichkeit, um die Treeview nach Namen zu filtern
- **Mehrfachauswahl**: `selectmode="extended"` in der Treeview, um mehrere Zeilen zu löschen
- **Spalten sortieren**: Klick auf die Spaltenüberschrift sortiert die Liste (ascending/descending)
- **Drag & Drop**: Zeilen per Drag & Drop neu sortieren
- **Tastenkürzel**: Strg+N für Neu, Strg+E für Bearbeiten, Entf für Löschen
- **Double-Click**: Doppelklick auf eine Zeile öffnet direkt den Bearbeiten-Dialog

---

## Prüfungen

### Code existiert und ist korrekt
- [ ] `ui/__init__.py` existiert mit erklärendem Kommentar
- [ ] `ui/character_editor.py` existiert mit Klasse `CharacterEditor(tk.Toplevel)`
- [ ] `CharacterEditor.__init__()` nimmt `parent` und `character_library` als Parameter entgegen
- [ ] `CharacterEditor` hat eine `ttk.Treeview` mit Spalten "Name" und "Beschreibung" (keine Bildvorschau)
- [ ] `CharacterEditor` hat drei Buttons: "Neuer Charakter", "Bearbeiten", "Löschen"
- [ ] "Bearbeiten" und "Löschen" sind initial deaktiviert (`state="disabled"`)
- [ ] "Neuer Charakter" öffnet einen Dialog mit Eingabefeldern für Name, Bildpfad, Beschreibung
- [ ] "Bearbeiten" öffnet denselben Dialog mit vorausgefüllten Werten
- [ ] "Löschen" zeigt `messagebox.askyesno` Bestätigungsdialog vor dem Löschen an
- [ ] Nach jeder Änderung wird `_refresh_list()` aufgerufen
- [ ] Es gibt einen "Schließen"-Button, der das Fenster schließt
- [ ] `app.py` importiert `CharacterEditor` aus `ui.character_editor`
- [ ] `app.py` hat einen "Charaktere verwalten"-Button bei `relx=0.5, rely=0.85`
- [ ] `app.py` hat die Methode `_open_character_editor()`, die `CharacterEditor(self, self.character_library)` erstellt

### App startet ohne Fehler
- [ ] `python app.py` startet ohne Fehlermeldung
- [ ] Der "Charaktere verwalten"-Button ist im Hauptfenster sichtbar
- [ ] Der Character Editor öffnet sich als Tochterfenster (transient)
- [ ] Die Treeview-Liste zeigt alle Charaktere mit Namen und Beschreibung an
- [ ] Die Liste ist alphabetisch sortiert

### Funktionalität (manuell testbar)
- [ ] **Neu**: "Neuer Charakter" öffnet Dialog, Name + Speichern erstellt einen neuen Charakter, Liste aktualisiert sich
- [ ] **Bearbeiten**: Zeile auswählen → "Bearbeiten" aktiv → Dialog mit vorausgefüllten Werten → Ändern + Speichern → Liste aktualisiert sich
- [ ] **Löschen**: Zeile auswählen → "Löschen" aktiv → Bestätigungsdialog erscheint → "Nein" = nichts passiert, "Ja" = Charakter gelöscht, Liste aktualisiert sich
- [ ] **Buttons deaktiviert**: Ohne Auswahl sind "Bearbeiten" und "Löschen" deaktiviert
- [ ] **Schließen**: Der "Schließen"-Button schließt das Editor-Fenster
- [ ] **JSON-Datei**: Nach Änderungen ist `assets/characters/character_data.json` aktualisiert
- [ ] **Sortierung**: Neue Charaktere erscheinen in alphabetischer Reihenfolge in der Liste

---

## Nachtrag: Echte Bildauswahl statt Text-Eingabe

Nach der ersten Version des Character Editors wurde der Bildpfad noch als freies Textfeld eingegeben – der Benutzer musste den Pfad zur Bilddatei von Hand eintippen. Das ist aus mehreren Gründen problematisch:

1. **Tippfehler**: Ein falscher Buchstabe im Pfad führt dazu, dass das Bild nicht gefunden wird.
2. **Absolute Pfade**: Der Benutzer gibt z.B. `C:\Users\Max\Bilder\held.png` ein – dieser Pfad funktioniert nur auf seinem Rechner, nicht auf einem anderen.
3. **Bild außerhalb des Projekts**: Wenn das Bild in einem anderen Ordner liegt (z.B. Downloads), kann es versehentlich gelöscht oder verschoben werden.
4. **Keine Validierung**: Der Benutzer kann irgendeinen Text eingeben, der gar kein gültiger Bildpfad ist.

Die Lösung: Ein **Windows-Dateidialog** (`filedialog.askopenfilename`) und automatisches **Kopieren** der ausgewählten Datei in das `assets/characters/`-Verzeichnis.

### Geänderte Imports

```python
# Importiert das ttk-Modul für erweiterte Widgets (Treeview), messagebox für Dialoge
# und filedialog für Dateiauswahl-Dialoge
from tkinter import ttk, messagebox, filedialog

# Importiert shutil zum Kopieren von Bilddateien in das assets/-Verzeichnis
import shutil

# Importiert os für Pfad-Operationen (Verzeichnisse prüfen, Dateinamen extrahieren)
import os
```

### Geänderter Bildpfad-Bereich in `_open_character_dialog()`

```python
# Bildpfad-Eingabe (schreibgeschützt, wird nur über "Durchsuchen..." gesetzt)
tk.Label(dialog, text="Bildpfad:").pack(pady=(10, 5))
image_var = tk.StringVar()

# Ein Frame für die horizontale Anordnung von Entry und Button
image_frame = tk.Frame(dialog)
image_frame.pack()

# Das Entry-Feld ist schreibgeschützt (state="readonly"), damit der Benutzer
# den Pfad nicht versehentlich von Hand falsch eingeben kann.
# Der Pfad wird ausschließlich über den "Durchsuchen..."-Button gesetzt.
image_entry = tk.Entry(
    image_frame,
    textvariable=image_var,
    width=35,
    state="readonly"
)
image_entry.pack(side="left", padx=(0, 5))

# "Durchsuchen..."-Button öffnet den Windows-Dateidialog zur Bildauswahl
# und kopiert die ausgewählte Datei automatisch in assets/characters/
tk.Button(
    image_frame,
    text="Durchsuchen...",
    command=lambda: self._select_image_file(image_var)
).pack(side="left")
```

### Neue Methode `_select_image_file()`

```python
def _select_image_file(self, image_var: tk.StringVar):
    """Öffnet einen Dateidialog zur Auswahl eines Charakter-Bildes.

    Der Benutzer wählt eine Bilddatei aus (*.png, *.jpg, *.jpeg, *.gif, *.bmp).
    Die Datei wird automatisch in den Ordner 'assets/characters/' kopiert,
    damit sie im Projektverzeichnis liegt und nicht versehentlich gelöscht wird.

    Falls im Zielordner bereits eine Datei mit demselben Namen existiert
    (und es nicht genau dieselbe Datei ist), wird ein eindeutiger Name
    durch Anhängen eines Zeitstempels erzeugt.

    Args:
        image_var: Die StringVar-Variable des Bildpfad-Eingabefelds.
                   Nach erfolgreicher Auswahl wird sie auf den relativen
                   Zielpfad gesetzt (z.B. "assets/characters/held.png").
    """
    # Windows-Dateidialog öffnen, nur Bildformate zulassen
    file_path = filedialog.askopenfilename(
        title="Charakterbild auswählen",
        filetypes=[
            ("Bilddateien", "*.png *.jpg *.jpeg *.gif *.bmp"),
            ("Alle Dateien", "*.*")
        ]
    )

    # Wenn der Benutzer "Abbrechen" geklickt hat, ist der Pfad leer -> nichts tun
    if not file_path:
        return

    # Zielverzeichnis: assets/characters/ (relativ zum Arbeitsverzeichnis)
    target_dir = "assets/characters"

    # Prüfen, ob das Zielverzeichnis existiert, ggf. erstellen
    os.makedirs(target_dir, exist_ok=True)

    # Nur den Dateinamen aus dem Quellpfad extrahieren (z.B. "held.png")
    filename = os.path.basename(file_path)

    # Zielpfad zusammensetzen: "assets/characters/held.png"
    target_path = os.path.join(target_dir, filename)

    # Prüfen, ob am Ziel bereits eine Datei mit diesem Namen existiert
    if os.path.exists(target_path):
        # Prüfen, ob es dieselbe Datei ist (gleicher Pfad)
        if os.path.abspath(file_path) != os.path.abspath(target_path):
            # Es ist eine andere Datei mit demselben Namen -> Zeitstempel anhängen
            # z.B. "held_1721234567.png"
            import time
            timestamp = int(time.time())
            name_without_ext, ext = os.path.splitext(filename)
            unique_filename = f"{name_without_ext}_{timestamp}{ext}"
            target_path = os.path.join(target_dir, unique_filename)

    # Die Quelldatei in den Zielordner kopieren
    # shutil.copy2() erhält die Datei-Metadaten (Erstellungsdatum etc.)
    shutil.copy2(file_path, target_path)

    # Den relativen Zielpfad in der image_var speichern,
    # damit er im Eingabefeld angezeigt und später in character_data.json gespeichert wird
    image_var.set(target_path)
```

### Erklärung der wichtigsten Punkte

#### Warum `state="readonly"`?
- Das Entry-Feld ist schreibgeschützt, damit der Benutzer den Pfad nicht von Hand eintippen kann.
- Der Pfad wird **ausschließlich** über den "Durchsuchen..."-Button gesetzt.
- Das verhindert Tippfehler und ungültige Pfade.

#### Warum `os.makedirs(target_dir, exist_ok=True)`?
- Stellt sicher, dass der Ordner `assets/characters/` existiert, bevor die Datei kopiert wird.
- `exist_ok=True` verhindert einen Fehler, falls der Ordner bereits existiert.

#### Warum `os.path.basename()`?
- Extrahiert nur den Dateinamen aus dem vollständigen Pfad (z.B. `held.png` aus `C:\Users\Max\Bilder\held.png`).
- So wird die Datei immer mit einem einfachen, relativen Pfad gespeichert.

#### Warum Zeitstempel bei Namenskonflikt?
- Wenn zwei verschiedene Charaktere Bilder mit demselben Dateinamen haben (z.B. beide `portrait.png`), würden sie sich gegenseitig überschreiben.
- Durch Anhängen eines Zeitstempels (`portrait_1721234567.png`) wird der Name eindeutig.
- Die Prüfung `os.path.abspath(file_path) != os.path.abspath(target_path)` verhindert, dass ein Zeitstempel angehängt wird, wenn der Benutzer genau dieselbe Datei erneut auswählt.

#### Warum `shutil.copy2()` statt `shutil.copy()`?
- `copy2()` erhält die Datei-Metadaten (Erstellungsdatum, Änderungsdatum).
- `copy()` würde nur den Inhalt kopieren, ohne Metadaten.
